const { test, expect } = require('@playwright/test');

test.describe('Headline Hub Navigation and Interaction Tests', () => {

  // Test navigation menu interactions
  test('should navigate to different sections on nav item click', async ({ page }) => {
    await page.goto('http://127.0.0.1:5500/indexnew.html');

    // Click on Sports
    await page.click('#ipl:has-text("Sports")');
    await expect(page).toHaveURL('http://127.0.0.1:5500/indexnew.html');

    // Click on India
    await page.click('#ipl:has-text("India")');
    await expect(page).toHaveURL('http://127.0.0.1:5500/indexnew.html');

    // Click on Education
    await page.click('#ipl:has-text("Education")');
    await expect(page).toHaveURL('http://127.0.0.1:5500/indexnew.html');

    // Click on Entertainment
    await page.click('#ipl:has-text("Entertainment")');
    await expect(page).toHaveURL('http://127.0.0.1:5500/indexnew.html');

    // Click on Finance
    await page.click('#ipl:has-text("Finance")');
    await expect(page).toHaveURL('http://127.0.0.1:5500/indexnew.html');
  });
    
  // Test dark/light mode toggle
  test('should toggle between dark and light mode', async ({ page }) => {
    await page.goto('http://127.0.0.1:5500/indexnew.html');

    // Toggle to dark mode
    await page.click('.dark-light .bx-moon');
    // Add assertion to check dark mode activation
    // (example: expect a certain class to be added to the body or element color change)

    // Toggle back to light mode
    await page.click('.dark-light .bx-sun');
    // Add assertion to check light mode activation
  });

  // Test search functionality
  test('should display search results', async ({ page }) => {
    await page.goto('http://127.0.0.1:5500/indexnew.html');

    await page.click('.searchToggle .bx-search');
    await page.fill('#search-text', 'headline');
    await page.click('#search-button');
    
    // Verify if search results or any interaction occurs
    // This part will depend on how your search is implemented and what should happen after clicking search
  });
});
