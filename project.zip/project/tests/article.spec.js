const { test, expect } = require('@playwright/test');

test.describe('Submission Form Tests', () => {

  // Test filling out and submitting the form
  test('should fill out the form and submit successfully', async ({ page }) => {
    await page.goto('http://localhost:3020/');

    // Fill in the Title
    await page.fill('#title', 'My Article Title');

    // Fill in the Content
    await page.fill('#content', 'This is the content of my article.');

    // Fill in the Author Name (optional)
    await page.fill('#author-name', 'Anuj Kumar');

    // Fill in the Date
    await page.fill('#date', '2024-08-22');

    // Attach a file for Proof (optional)
   // const filePath = path.join(__dirname, 'sample-proof.pdf');
   // await page.setInputFiles('#proof', filePath);

    // Submit the form
    await page.click('input[type="submit"]');

    // Check if the form submission was successful (depends on your implementation)
    // Example:
    // await expect(page).toHaveURL(/.*thank-you/);
  });

  // Test required fields validation
  test('should validate required fields', async ({ page }) => {
    await page.goto('http://localhost:3020');

    // Clear any pre-filled values to ensure the form is empty
    await page.fill('#title', 'My title' , { timeout: 15000 });
    await page.fill('#content', 'This is content');
    await page.fill('#date', '2024-08-22');

    // Try to submit the form without filling required fields
    await page.click('input[type="submit"]');

  });
});
