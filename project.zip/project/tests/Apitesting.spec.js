const { test, expect } = require('@playwright/test');

test.describe('GET Method API Testing with Playwright', () => {

  const apiKey = '6a450cf38fcd4c89827dd3199bf04e39';
  const baseURL = 'https://newsapi.org/v2/everything';

  test('GET /everything?q=Apple should return a list of articles about Apple', async ({ request }) => {
    const response = await request.get(`${baseURL}?q=Apple`, {
      headers: {
        'Authorization': `Bearer ${apiKey}`
      }
    });

    console.log('Response status:', response.status());
    console.log('Response body:', await response.text());

    expect(response.ok()).toBeTruthy(); // Check if the response status is 200
    const data = await response.json();
    expect(data.status).toBe('ok'); // Check if the API returned a successful status
    expect(Array.isArray(data.articles)).toBeTruthy(); // Check if articles are returned in an array
    expect(data.articles.length).toBeGreaterThan(0); // Check if there are articles in the array
  });

  test('GET /everything?q=NonExistentTopic should return no articles', async ({ request }) => {
    const response = await request.get(`${baseURL}?q=NonExistentTopic`, {
      headers: {
        'Authorization': `Bearer ${apiKey}`
      }
    });

    console.log('Response status:', response.status());
    console.log('Response body:', await response.text());

    expect(response.ok()).toBeTruthy(); // Check if the response status is 200
    const data = await response.json();
    expect(data.status).toBe('ok'); // Check if the API returned a successful status
    expect(data.articles.length).toBe(0); // Check if no articles are returned
  });

});
