const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const multer = require('multer');
const fs = require('fs');
const app = express();
const port = 3020;

// Middleware to serve static files and parse form data
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

// MongoDB connection
// MongoDB connection
mongoose.connect('mongodb://127.0.0.1:27017/articles');

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});


// Define a schema and model for the article
const articleSchema = new mongoose.Schema({
  title: { type: String, required: true },
  content: { type: String, required: true },
  author_name: String,
  date: { type: Date, required: true },
  proof: String, // Store the file path as a string
});

const Article = mongoose.model('article', articleSchema);

// Set up multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  },
});

const upload = multer({ storage: storage });

// Serve the HTML form
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'article.html'));
});

// Handle form submission
app.post('/post', upload.single('proof'), async (req, res) => {
  const { title, content, author_name, date } = req.body;

  const newArticle = new Article({
    title,
    content,
    author_name,
    date,
    proof: req.file ? req.file.path : null, // Save the file path if a file was uploaded
  });

  try {
    await newArticle.save();
    console.log('Article saved:', newArticle);
    res.send('Form submission successful');
  } catch (error) {
    console.error('Error saving article:', error);
    res.status(500).send('Error saving data');
  }
});

// Ensure the uploads directory exists
if (!fs.existsSync('uploads')) {
  fs.mkdirSync('uploads');
}

// Start the server
app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});
